package ui;

import dao.ExpenseDAO;
import model.Expense;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.SQLException;
import java.util.List;

public class ExpenseTable extends JPanel {
    private JTable table;
    private DefaultTableModel model;
    private ExpenseDAO expenseDAO;
    private JLabel totalLabel;

    public ExpenseTable(ExpenseDAO dao) {
        this.expenseDAO = dao;
        setLayout(new BorderLayout());

        model = new DefaultTableModel(new String[]{"ID", "Category", "Amount", "Description", "Date"}, 0);
        table = new JTable(model);

        add(new JScrollPane(table), BorderLayout.CENTER);

        totalLabel = new JLabel("Total Expense: 0.0");
        add(totalLabel, BorderLayout.SOUTH);

        refreshTable();
    }

    public void refreshTable() {
        try {
            model.setRowCount(0);
            List<Expense> expenses = expenseDAO.getAllExpenses();
            for (Expense exp : expenses) {
                model.addRow(new Object[]{
                        exp.getId(),
                        exp.getCategory(),
                        exp.getAmount(),
                        exp.getDescription(),
                        exp.getExpenseDate()
                });
            }
            totalLabel.setText("Total Expense: " + expenseDAO.getTotalExpense());
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error loading data: " + e.getMessage());
        }
    }
}
