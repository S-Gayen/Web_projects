package ui;

import dao.ExpenseDAO;
import model.Expense;

import javax.swing.*;
import java.awt.*;
import java.sql.Date;

public class ExpenseForm extends JPanel {
    private JTextField categoryField, amountField, descriptionField, dateField;
    private JButton addButton;
    private ExpenseDAO expenseDAO;
    private ExpenseTable expenseTable;

    public ExpenseForm(ExpenseDAO dao, ExpenseTable table) {
        this.expenseDAO = dao;
        this.expenseTable = table;

        setLayout(new GridLayout(5, 2, 5, 5));

        add(new JLabel("Category:"));
        categoryField = new JTextField();
        add(categoryField);

        add(new JLabel("Amount:"));
        amountField = new JTextField();
        add(amountField);

        add(new JLabel("Description:"));
        descriptionField = new JTextField();
        add(descriptionField);

        add(new JLabel("Date (YYYY-MM-DD):"));
        dateField = new JTextField();
        add(dateField);

        addButton = new JButton("Add Expense");
        add(addButton);

        addButton.addActionListener(e -> {
            try {
                String category = categoryField.getText();
                double amount = Double.parseDouble(amountField.getText());
                String description = descriptionField.getText();
                Date date = Date.valueOf(dateField.getText());

                Expense expense = new Expense(category, amount, description, date);
                expenseDAO.addExpense(expense);

                JOptionPane.showMessageDialog(this, "Expense Added!");
                expenseTable.refreshTable();
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage());
            }
        });
    }
}
