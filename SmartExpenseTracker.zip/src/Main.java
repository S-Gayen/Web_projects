import dao.ExpenseDAO;
import ui.ExpenseForm;
import ui.ExpenseTable;

import javax.swing.*;
import java.awt.*;

public class Main {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            ExpenseDAO dao = new ExpenseDAO();
            ExpenseTable tablePanel = new ExpenseTable(dao);
            ExpenseForm formPanel = new ExpenseForm(dao, tablePanel);

            JFrame frame = new JFrame("Smart Expense Tracker");
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            frame.setLayout(new BorderLayout());

            frame.add(formPanel, BorderLayout.NORTH);
            frame.add(tablePanel, BorderLayout.CENTER);

            frame.setSize(800, 600);
            frame.setVisible(true);
        });
    }
}
