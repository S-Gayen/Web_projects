package model;

import java.sql.Date;

public class Expense {
    private int id;
    private String category;
    private double amount;
    private String description;
    private Date expenseDate;

    public Expense(int id, String category, double amount, String description, Date expenseDate) {
        this.id = id;
        this.category = category;
        this.amount = amount;
        this.description = description;
        this.expenseDate = expenseDate;
    }

    public Expense(String category, double amount, String description, Date expenseDate) {
        this(-1, category, amount, description, expenseDate);
    }

    public int getId() { return id; }
    public String getCategory() { return category; }
    public double getAmount() { return amount; }
    public String getDescription() { return description; }
    public Date getExpenseDate() { return expenseDate; }
}
